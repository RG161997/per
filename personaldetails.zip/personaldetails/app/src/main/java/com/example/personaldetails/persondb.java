package com.example.personaldetails;

public class persondb {

}
