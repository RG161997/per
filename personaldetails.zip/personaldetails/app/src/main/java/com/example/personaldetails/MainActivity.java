package com.example.personaldetails;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText personName,personHobby,personInterest,personFavProgLang,personFavTextEditor;
    Button insertData,updateData;
    SQLiteOpenHelper helper;
    SQLiteDatabase database;
    //
    boolean isEmpty(EditText text)
    {
        CharSequence str=text.getText().toString();
        return TextUtils.isEmpty(str);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        personName = (EditText) findViewById(R.id.person_name);
        personHobby = (EditText) findViewById(R.id.person_hobby);
        personInterest = (EditText) findViewById(R.id.person_interest);
        personFavProgLang = (EditText) findViewById(R.id.person_fav_prog_lang);
        personFavTextEditor = (EditText) findViewById(R.id.person_fav_text_editor);
        insertData = (Button) findViewById(R.id.insert_data);
        updateData = (Button) findViewById(R.id.update_data);
//To show the default values
        helper = new MyHelper(this);
        database = helper.getWritableDatabase();
        Cursor cursor = database.rawQuery("SELECT PERSON_NAME,PERSON_HOBBY,PERSON_INTEREST,PERSON_FAV_PROG_LANG,PERSON_FAV_TEXT_EDITOR FROM PERSONAL_DETAILS", new String[]{});
        int count = cursor.getCount();
        if (count == 1)
        {
            insertData.setVisibility(View.INVISIBLE);
            if (cursor != null)
            {
                cursor.moveToFirst();
            }
            do {
                String person_name = cursor.getString(0);
                String person_hobby = cursor.getString(1);
                String person_interest = cursor.getString(2);
                String person_fav_prog_lang = cursor.getString(3);
                String person_fav_text_editor = cursor.getString(4);
                personName.setText(person_name.toString());
                personHobby.setText(person_hobby.toString());
                personInterest.setText(person_interest.toString());
                personFavProgLang.setText(person_fav_prog_lang.toString());
                personFavTextEditor.setText(person_fav_text_editor.toString());
            } while (cursor.moveToNext());
        }
//Insert data in SQLite database
        insertData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String personname = personName.getText().toString();
                String personhobby = personHobby.getText().toString();
                String personinterest = personInterest.getText().toString();
                String personfavproglang = personFavProgLang.getText().toString();
                String personfavtexteditor = personFavTextEditor.getText().toString();
                database = helper.getWritableDatabase();
                if (isEmpty(personName))
                {
                    Toast.makeText(getApplicationContext(), "Please enter name...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personHobby))
                {
                    Toast.makeText(getApplicationContext(), "Please enter hobby...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personInterest))
                {
                    Toast.makeText(getApplicationContext(), "Please enter interest...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personFavProgLang))
                {
                    Toast.makeText(getApplicationContext(), "Please enter favourite programming language...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personFavTextEditor))
                {
                    Toast.makeText(getApplicationContext(), "Please enter favourite text editor...", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    insert_person_details(personname, personhobby, personinterest, personfavproglang, personfavtexteditor);
                    Toast.makeText(getApplicationContext(), "Data inserted successfully", Toast.LENGTH_SHORT).show();
                    insertData.setVisibility(view.INVISIBLE);
                }
            }
        });
//Update data in SQLite database
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String personname = personName.getText().toString();
                String personhobby = personHobby.getText().toString();
                String personinterest = personInterest.getText().toString();
                String personfavproglang = personFavProgLang.getText().toString();
                String personfavtexteditor = personFavTextEditor.getText().toString();
                database = helper.getWritableDatabase();
                if (isEmpty(personName))
                {
                    Toast.makeText(getApplicationContext(), "Please enter name...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personHobby))
                {
                    Toast.makeText(getApplicationContext(), "Please enter hobby...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personInterest))
                {
                    Toast.makeText(getApplicationContext(), "Please enter interest...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personFavProgLang))
                {
                    Toast.makeText(getApplicationContext(), "Please enter favourite programming language...", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(personFavTextEditor))
                {
                    Toast.makeText(getApplicationContext(), "Please enter favourite text editor...", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    ContentValues values=new ContentValues();
                    values.put("PERSON_NAME",personname);
                    values.put("PERSON_HOBBY",personhobby);
                    values.put("PERSON_INTEREST",personinterest);
                    values.put("PERSON_FAV_PROG_LANG",personfavproglang);
                    values.put("PERSON_FAV_TEXT_EDITOR",personfavtexteditor);
                    database.update("PERSONAL_DETAILS", values,"PERSON_NAME = ?", new String[]{personname});
                    Toast.makeText(getApplicationContext(), "Data updated successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void insert_person_details(String person_name,String person_hobby,String person_interest,String person_fav_prog_lang,String person_fav_text_editor)
    {
        ContentValues values=new ContentValues();
        values.put("PERSON_NAME",person_name);
        values.put("PERSON_HOBBY",person_hobby);
        values.put("PERSON_INTEREST",person_interest);
        values.put("PERSON_FAV_PROG_LANG",person_fav_prog_lang);
        values.put("PERSON_FAV_TEXT_EDITOR",person_fav_text_editor);
        database.insert("PERSONAL_DETAILS",null,values);
    }
}


    }
}